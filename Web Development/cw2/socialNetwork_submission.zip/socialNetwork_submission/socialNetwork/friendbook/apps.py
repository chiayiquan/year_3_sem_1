from django.apps import AppConfig


class FriendbookConfig(AppConfig):
    name = 'friendbook'
