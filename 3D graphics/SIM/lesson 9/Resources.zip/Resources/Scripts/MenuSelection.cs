using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuSelection : MonoBehaviour
{
    public void StartGame()
    {
        Debug.Log("Start the game");
    }

    public void LoadGame()
    {
        Debug.Log("Load a game");
    }

    public void ExitGame()
    { 
        Debug.Log("Exit game");
    }

    public void Tips()
    {
        Debug.Log("Tips");
    }

}
