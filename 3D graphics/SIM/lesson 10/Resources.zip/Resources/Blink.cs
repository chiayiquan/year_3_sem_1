using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blink : MonoBehaviour
{
    // This is the component that holds the blend shapes
    // you set this in the inspector so this script doesn't 
    // have to be on the same object
    [SerializeField]
    SkinnedMeshRenderer skinnedMeshRenderer;

    // the name of the blend shape we are using
    public string blinkBlendShapeName;
    // how long the character blinks for
    public float blinkLength;
    // the time between blinks
    public float blinkInterval;

    // these two are private variables that are set in the script

    // the time at which the character will blink next
    float timeToNextBlink;
    // the index of the blend shape we are using
    int blinkBlendShapeIndex;

    void Start()
    {
        // set the time of the first blink to be blinkInterval
        timeToNextBlink = blinkInterval;

        // get the index of the blend shape from the skinned mesh renderer 
        // by searching for its name
        blinkBlendShapeIndex = skinnedMeshRenderer.sharedMesh.GetBlendShapeIndex(blinkBlendShapeName);
    }

    // Update is called once per frame
    void Update()
    {
        // if we have reached the time of the next blink
        if (Time.time > timeToNextBlink)
        {
            // if the time since the start of the blink is less than the 
            // length of the blink
            if (Time.time < timeToNextBlink + blinkLength)
            {
                // set the blend shape weight to 100 (fully on)
                skinnedMeshRenderer.SetBlendShapeWeight(blinkBlendShapeIndex, 100);
            }
            else
            {
                // if we reach this branch it means that we have reached the end of the blink

                // set the blend shape to 0 (off)
                skinnedMeshRenderer.SetBlendShapeWeight(blinkBlendShapeIndex, 0);

                // set the time of the next blink to be "blinkInterval" 
                // seconds in the future
                timeToNextBlink = Time.time + blinkInterval;
            }

        }
    }
}